#include <iostream>
#include <cmath>
#include <fstream>
#include <opencv2/opencv.hpp>

using namespace std;
using namespace cv;

void calculateAccuracy(int** arr, int** arr1, int row, int col) {
    double X = 0;
    int sum = row * col;

    for (int i = 0; i < row; i++) {
        for (int j = 0; j < col; j++) {
            int diff = abs(arr[i][j] - arr1[i][j]);
            X += pow(diff, 2);
        }
    }

    // Calculate accuracy
    double Y = 100.0 * (1 - (X / (255.0 * 255.0 *sum)));
    cout << "ACCURACY IS " << Y << "%" << endl;
}

int main() {
    Mat img = imread("C:\\Users\\Shekhani Laptops\\source\\repos\\opencvprojectA4\\opencvprojectA4\\t1.bmp");
    Mat img2 = imread("C:\\Users\\Shekhani Laptops\\source\\repos\\opencvprojectA4\\opencvprojectA4\\t3.bmp");

    if (img.empty()) {
        cerr << "Loading image unsuccessful" << endl;
        return 1;
    }
    if (img2.empty()) {
        cerr << "Loading image unsuccessful" << endl;
        return 1;
    }

    int rows = img.rows;
    int cols = img.cols;

    int** pixel_arr = new int* [rows];
    for (int i = 0; i < rows; i++) {
        pixel_arr[i] = new int[cols];
    }

    int** pixel_arr2 = new int* [rows];
    for (int i = 0; i < rows; i++) {
        pixel_arr2[i] = new int[cols];
    }

    for (int i = 0; i < rows; i++) {
        for (int j = 0; j < cols; j++) {
            pixel_arr[i][j] = static_cast<int>(img.at<uchar>(i, j));
        }
    }

    for (int i = 0; i < rows; i++) {
        for (int j = 0; j < cols; j++) {
            pixel_arr2[i][j] = static_cast<int>(img2.at<uchar>(i, j));
        }
    }
    //...it will calcu;ate the accuracy of the pixel
    calculateAccuracy(pixel_arr, pixel_arr2, rows, cols);

    // Deallocate memory
   
    return 0;
}
