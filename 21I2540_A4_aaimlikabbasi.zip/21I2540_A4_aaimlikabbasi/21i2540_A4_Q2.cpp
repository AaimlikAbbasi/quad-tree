#include <iostream>
#include <fstream>
#include <string>
using namespace std;

struct TreeNode {
    int** data;
    int size;
    string quad;
    string color;
    TreeNode* q1;
    TreeNode* q2;
    TreeNode* q3;
    TreeNode* q4;
    TreeNode() {
        data = nullptr;
        size = 0;
        q1 = nullptr;
        q2 = nullptr;
        q3 = nullptr;
        q4 = nullptr;
        quad = "";
        color = "";
    }
};

struct QuadTree {
    TreeNode* root;
    QuadTree() {
        root = nullptr;
    }

    // Function to read Quad tree from the file
    void readTreeFromFile(const string& filename, TreeNode*& node) {
        ifstream file(filename);

        if (!file.is_open()) {
            cout << "Failed to open the file." << endl;
            return;
        }

        string line;
        string temp;
        getline(file, line);
        file.close();

        if (line.empty()) {
            return;
        }

        int pos = line.find("Position: ");
        node = new TreeNode();
        node->quad = line.substr(pos + 10, 2);

        pos = line.find("Color:");
        node->color = line.substr(pos + 7);

        if (node->quad == "root") {
            // Read root data
            readTreeFromFile("root.txt", node->q1);
            readTreeFromFile("q1.txt", node->q1);
            readTreeFromFile("q2.txt", node->q2);
            readTreeFromFile("q3.txt", node->q3);
            readTreeFromFile("q4.txt", node->q4);
        }
    }

    // Function to build the Quad tree
    void buildTree(TreeNode*& root) {
        if (root == nullptr || root->color != "grey" || root->size == 1) {
            return;
        }

        buildTree(root->q1);
        buildTree(root->q2);
        buildTree(root->q3);
        buildTree(root->q4);
    }
    void displayTree(TreeNode* node, int level = 0) {
        if (node == nullptr) {
            return;
        }

        // Indentation based on the level
        for (int i = 0; i < level; i++) {
            cout << "  ";
        }

        // Print node information
        cout << "Quad: " << node->quad << ", Color: " << node->color << endl;

        // Recursively display child nodes
        displayTree(node->q1, level + 1);
        displayTree(node->q2, level + 1);
        displayTree(node->q3, level + 1);
        displayTree(node->q4, level + 1);
    }
};


int main() {
    QuadTree quadTree;

    // Read Quad tree from the file
    quadTree.readTreeFromFile("root.txt", quadTree.root);

    // Build the Quad tree
    quadTree.buildTree(quadTree.root);

    // Use the Quad tree as needed
    quadTree.displayTree(quadTree.root);
    return 0;
}

