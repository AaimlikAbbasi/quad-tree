
//#include <opencv2/core.hpp>
//#include <opencv2/imgcodecs.hpp>
//#include <opencv2/highgui.hpp>
//#include <iostream>
//using namespace cv;
//using namespace std;
//struct node
//{
//    int data;
//    node* right;
//    node* down;
//    node(int d)
//    {
//        data = d;
//        right = NULL;
//        down = NULL;
//    }
//};
//
//// Global variables
//node** head = NULL;
//node** tail = NULL;
/////implementation of 2 D link list 
//void insert(int row, int value)
//{
//    node* newNode = new node(value);
//
//    if (head[row] == NULL)
//    {
//        head[row] = newNode;
//    }
//    else
//    {
//        node* current = head[row];
//        while (current->right != NULL)
//        {
//            current = current->right;
//        }
//        current->right = newNode;
//    }
//
//    if (row > 0)
//    {
//        node* prevRowNode = head[row - 1];
//        while (prevRowNode != NULL && prevRowNode->right != NULL)
//        {
//            prevRowNode = prevRowNode->right;
//            if (prevRowNode != NULL)
//            {
//                newNode->down = prevRowNode;
//            }
//        }
//    }
//}
//
//
//void convertTo2dLL(int **arr, int row, int col)
//{
//    head = new node * [row];
//    tail = new node * [row];
//
//    for (int i = 0; i < row; i++)
//    {
//        head[i] = NULL;
//        tail[i] = NULL;
//
//        insert(i, i + 1); // Insert starting location
//
//        int count = 0;
//        for (int j = 0; j < col; j++)
//        {
//            if (arr[i][j] == 0)
//            {
//                if (count == 0)
//                    insert(i, j + 1); // Insert starting location
//
//                count++;
//            }
//            else if (arr[i][j] == 255)
//            {
//                if (count > 0)
//                    insert(i, j); // Insert ending location of white location
//
//                count = 0;
//            }
//        }
//
//        if (count > 0)
//            insert(i, col); // Insert ending location of white location
//
//        count = 0;
//        insert(i, -2);
//        for (int k = 0; k < col; k++)
//        {
//            if (arr[i][k] == 255)
//            {
//                if (count == 0)
//                    insert(i, k + 1); // Insert starting location
//
//                count++;
//            }
//            else if (arr[i][k] == 0)
//            {
//                if (count > 0)
//                    insert(i, k); // Insert ending location of black location
//
//                count = 0;
//            }
//        }
//
//        if (count > 0)
//            insert(i, col); // Insert ending location of black location
//
//        insert(i, -1); // Insert separator node
//    }
//
//    // Print the 2D linked list for testing
//    for (int i = 0; i < row; i++)
//    {
//        node* current = head[i];
//        while (current != NULL)
//        {
//            cout << current->data << ":";
//            current = current->right;
//        }
//        cout << endl;
//    }
//
//    // Cleanup: free memory
//    for (int i = 0; i < row; i++)
//    {
//        node* current = head[i];
//        while (current != NULL)
//        {
//            node* temp = current;
//            current = current->right;
//            delete temp;
//        }
//    }
//    delete[] head;
//  
//}
//
//
//
//int main()
//{
//   
//    cv::Mat img = cv::imread("C:\\Users\\Shekhani Laptops\\source\\repos\\opencvprojectA4\\opencvprojectA4\\t2.bmp");
//
//    
//
//    int rows = img.rows;
//    int cols = img.cols;
//
//    // Allocate memory for the 2D DMA
//    uchar** dma = new uchar * [rows];
//    for (int i = 0; i < rows; ++i) {
//        dma[i] = new uchar[cols];
//    }
//
//    // Copy image data to the 2D DMA
//    for (int i = 0; i < rows; ++i) {
//        for (int j = 0; j < cols; ++j) {
//            dma[i][j] = img.at<uchar>(i, j);
//        }
//    }
//    int** arr = new int*[rows];
//    for (int j = 0; j < rows; j++)
//        arr[j] = new int[cols];
//
//    // Access and print the pixel values from the 2D DMA
//    for (int i = 0; i < rows; ++i) {
//        for (int j = 0; j < cols; ++j) {
//            arr[i][j]= static_cast<int>(dma[i][j]);
//        }
//       
//    }
//
//    /*for (int i = 0; i < rows; ++i) {
//        for (int j = 0; j < cols; ++j) {
//            cout << arr[i][j] << " ";
//        }
//        cout << endl;
//    }*/
//    convertTo2dLL(arr, rows, cols);
//
//    // Deallocate memory for the 2D DMA
//
//    namedWindow("First OpenCV Application", cv::WINDOW_AUTOSIZE);
//    cv::imshow("First OpenCV Application", img);
//    cv::moveWindow("First OpenCV Application", 0, 45);
//    cv::waitKey(0);
//    cv::destroyAllWindows();
//
//    return 0;
//}
//

//
//#include <iostream>
//#include <fstream>
//#include <opencv2/opencv.hpp>
//
//using namespace std;
//using namespace cv;
//
//
//struct TreeNode {
//    int** data;
//    int size;
//    string quad, color;
//    TreeNode* q1;
//    TreeNode* q2;
//    TreeNode* q3;
//    TreeNode* q4;
//    TreeNode() {
//        data = NULL;
//        size = 0;
//        q1 = NULL;
//        q2 = NULL;
//        q3 = NULL;
//        q4 = NULL;
//        quad = "";
//        color = "";
//    }
//};
//
//struct QuadTree {
//    TreeNode* root;
//    QuadTree() {
//        root = NULL;
//    }
//
//    // Function for checking color of the given quadrant
//    string colorCheck(int** arr, int start, int end) {
//        string clr = "";
//        for (int i = start; i < end; i++) {
//            for (int j = start; j < end; j++) {
//
//                if (arr[i][j] == 0 && clr != "white") {
//                    clr = "black";
//                }
//                else if (arr[i][j] == 255 && clr != "black") {
//                    clr = "white";
//                }
//                else {
//                    clr = "grey";
//                    return clr;
//                }
//            }
//        }
//    }
//
//    // Function to build the quad tree
//    void buildTree(TreeNode*& root, int** arr, int size) {
//        if (root == NULL) {
//            root = new TreeNode();
//            root->data = arr;
//            root->size = size;
//            root->color = colorCheck(arr, 0, size);
//            root->quad = "root";
//        }
//
//        //base condition for the function, color is not qrey or quadrant size is 1
//        if (root->color != "grey" || root->size == 1) {
//            return;
//        }
//
//        if (root->color == "grey") {
//            int quadSize = size / 2;
//            int** q1_arr = new int* [quadSize];
//            int** q2_arr = new int* [quadSize];
//            int** q3_arr = new int* [quadSize];
//            int** q4_arr = new int* [quadSize];
//
//            for (int i = 0; i < quadSize; i++) {
//                q1_arr[i] = new int[quadSize];
//                q2_arr[i] = new int[quadSize];
//                q3_arr[i] = new int[quadSize];
//                q4_arr[i] = new int[quadSize];
//            }
//
//            for (int i = 0; i < quadSize; i++) {
//                for (int j = 0; j < quadSize; j++) {
//                    q1_arr[i][j] = arr[i][j];
//                    q2_arr[i][j] = arr[i][j + quadSize];
//                    q3_arr[i][j] = arr[i + quadSize][j];
//                    q4_arr[i][j] = arr[i + quadSize][j + quadSize];
//                }
//            }
//
//            root->q1 = new TreeNode();
//            root->q1->data = q1_arr;
//            root->q1->size = quadSize;
//            root->q1->color = colorCheck(q1_arr, 0, quadSize);
//            root->q1->quad = "q1";
//
//            root->q2 = new TreeNode();
//            root->q2->data = q2_arr;
//            root->q2->size = quadSize;
//            root->q2->color = colorCheck(q2_arr, 0, quadSize);
//            root->q2->quad = "q2";
//
//            root->q3 = new TreeNode();
//            root->q3->data = q3_arr;
//            root->q3->size = quadSize;
//            root->q3->color = colorCheck(q3_arr, 0, quadSize);
//            root->q3->quad = "q3";
//
//            root->q4 = new TreeNode();
//            root->q4->data = q4_arr;
//            root->q4->size = quadSize;
//            root->q4->color = colorCheck(q4_arr, 0, quadSize);
//            root->q4->quad = "q4";
//
//            buildTree(root->q1, q1_arr, quadSize);
//            buildTree(root->q2, q2_arr, quadSize);
//            buildTree(root->q3, q3_arr, quadSize);
//            buildTree(root->q4, q4_arr, quadSize);
//        }
//    }
//
//    void writeTree(TreeNode* root) {
//        if (root == NULL) {
//            return;
//        }
//        if (root->quad == "root") {
//            ofstream myfile;
//            myfile.open("root.txt");
//            myfile << "";
//            myfile.close();
//            myfile.open("q1.txt");
//            myfile << "";
//            myfile.close();
//            myfile.open("q2.txt");
//            myfile << "";
//            myfile.close();
//            myfile.open("q3.txt");
//            myfile << "";
//            myfile.close();
//            myfile.open("q4.txt");
//            myfile << "";
//            myfile.close();
//
//        }
//        ofstream myfile;
//        myfile.open(root->quad + ".txt", ios::app);
//        myfile << "Position: " << root->quad << " Color:" << root->color;
//        myfile << " q1:" << root->q1;
//        myfile << " q2:" << root->q2;
//        myfile << " q3:" << root->q3;
//        myfile << " q4:" << root->q4;
//        myfile << endl;
//        myfile.close();
//        writeTree(root->q1);
//        writeTree(root->q2);
//        writeTree(root->q3);
//        writeTree(root->q4);
//
//    }
//
//};
//int main() {
//
//    // Read the image file into a cv::Mat object
//    Mat img = imread("C:\\Users\\Shekhani Laptops\\source\\repos\\opencvprojectA4\\opencvprojectA4\\t2.bmp");
//
//    // Check if the image was successfully loaded
//    if (img.empty()) {
//        cerr << "loading image unsuccessful" << endl;
//        return 1;
//    }
//
//    int size = img.rows;
//
//
//    int** pixel_arr = new int* [size];
//    for (int i = 0; i < size; i++) {
//        pixel_arr[i] = new int[size];
//    }
//
//    for (int i = 0; i < size; i++) {
//        for (int j = 0; j < size; j++) {
//            pixel_arr[i][j] = static_cast<int>(img.at<uchar>(i, j));
//        }
//
//    }
//
//    //write pixels to file
//    ofstream myfile;
//    myfile.open("pixels.txt");
//    for (int i = 0; i < size; i++) {
//        for (int j = 0; j < size; j++) {
//            myfile << pixel_arr[i][j] << " , ";
//        }
//        myfile << "\n";
//    }
//    myfile.close();
//
//    //build quadtree
//    QuadTree qt;
//    qt.buildTree(qt.root, pixel_arr, size);
//    //write quadtree to file based on position of nodes
//    qt.writeTree(qt.root);
//
//    return 0;
//}





#include <iostream>
#include <fstream>
#include <opencv2/opencv.hpp>

using namespace std;
using namespace cv;


struct ListNode {
    int  data;
    ListNode* nextColumn;
    ListNode* nextRow;
    ListNode() {
        nextColumn = NULL;
        nextRow = NULL;
        data = -3;
    }
};

struct LinkedList {
    ListNode* head;
    LinkedList() {
        head = NULL;
    }

    void insert(int data, bool moveRow) {
        if (head == NULL) {
            head = new ListNode();
            head->data = 1;
            head->nextColumn = new ListNode();
            head->nextColumn->data = data;
            return;

        }

        ListNode* temp = head;

        if (moveRow) {
            while (temp->nextRow != NULL) {
                temp = temp->nextRow;
            }
            temp->nextRow = new ListNode();
            temp->nextRow->data = temp->data + 1;
            return;
        }

        while (temp->nextRow != NULL) {
            temp = temp->nextRow;
        }
        while (temp->nextColumn != NULL) {
            temp = temp->nextColumn;
        }
        temp->nextColumn = new ListNode();
        temp->nextColumn->data = data;

    }

    void convertTo2dLL(int** array, int row, int col) {
        bool black_color = false, white_color = false;

        for (int i = 0; i < row; i++) {
            for (int j = 0; j < col; j++) {
                if (array[i][j] == 0 && !black_color && !white_color) {
                    white_color = false;
                    black_color = true;
                    insert(j, false);
                }
                else if (array[i][j] == 255 && !black_color && !white_color) {
                    white_color = true;
                    black_color = false;
                    insert(j, false);
                }
                else if (array[i][j] == 0 && white_color) {
                    white_color = false;
                    black_color = true;
                    insert(j - 1, false);
                    insert(-2, false);
                    insert(j, false);
                }
                else if (array[i][j] == 255 && black_color) {
                    white_color = true;
                    black_color = false;
                    insert(j - 1, false);
                    insert(-1, false);
                    insert(j, false);
                }
            }
            if (black_color) {
                insert(col - 1, false);
                insert(-1, false);
            }
            else if (white_color) {
                insert(col - 1, false);
                insert(-2, false);
            }
            black_color = false;
            white_color = false;
            if (i != row - 1) {
                insert(-3, true);
            }
        }

    }

    void writeToFile() {
        ofstream myfile;
        myfile.open("2dLL.txt");
        ListNode* temp = head;
        while (temp != NULL) {
            ListNode* temp2 = temp;
            while (temp2 != NULL) {
                myfile << temp2->data << " ";
                temp2 = temp2->nextColumn;
            }
            myfile << endl;
            temp = temp->nextRow;
        }
    }

};

struct TreeNode {
    int** data;
    int size;
    string quad, color;
    TreeNode* q1;
    TreeNode* q2;
    TreeNode* q3;
    TreeNode* q4;
    TreeNode() {
        data = NULL;
        size = 0;
        q1 = NULL;
        q2 = NULL;
        q3 = NULL;
        q4 = NULL;
        quad = "";
        color = "";
    }
};

struct QuadTree {
    TreeNode* root;
    QuadTree() {
        root = NULL;
    }

    string colorCheck(int** arr, int size) {
        string clr = "";
        for (int i = 0; i < size; i++) {
            for (int j = 0; j < size; j++) {

                if (arr[i][j] == 0 && clr != "white") {
                    clr = "black";
                }
                else if (arr[i][j] == 255 && clr != "black") {
                    clr = "white";
                }
                else {
                    clr = "grey";
                    return clr;
                }
            }
        }

    }


    // Function to build the quad tree
    void buildTree(TreeNode*& root, int** arr, int size) {
        if (root == NULL) {
            root = new TreeNode();
            root->data = arr;
            root->size = size;
            root->color = colorCheck(arr, size);
            root->quad = "root";
        }

        //base condition for the function, color is not qrey or quadrant size is 1
        if (root->color != "grey" || root->size == 1) {
            return;
        }

        if (root->color == "grey") {
            int quadSize = size / 2;
            int** q1_arr = new int* [quadSize];
            int** q2_arr = new int* [quadSize];
            int** q3_arr = new int* [quadSize];
            int** q4_arr = new int* [quadSize];

            for (int i = 0; i < quadSize; i++) {
                q1_arr[i] = new int[quadSize];
                q2_arr[i] = new int[quadSize];
                q3_arr[i] = new int[quadSize];
                q4_arr[i] = new int[quadSize];
            }

            for (int i = 0; i < quadSize; i++) {
                for (int j = 0; j < quadSize; j++) {
                    q1_arr[i][j] = arr[i][j];
                    q2_arr[i][j] = arr[i][j + quadSize];
                    q3_arr[i][j] = arr[i + quadSize][j];
                    q4_arr[i][j] = arr[i + quadSize][j + quadSize];
                }
            }

            root->q1 = new TreeNode();
            root->q1->data = q1_arr;
            root->q1->size = quadSize;
            root->q1->color = colorCheck(q1_arr, quadSize);
            root->q1->quad = "q1";

            root->q2 = new TreeNode();
            root->q2->data = q2_arr;
            root->q2->size = quadSize;
            root->q2->color = colorCheck(q2_arr, quadSize);
            root->q2->quad = "q2";

            root->q3 = new TreeNode();
            root->q3->data = q3_arr;
            root->q3->size = quadSize;
            root->q3->color = colorCheck(q3_arr, quadSize);
            root->q3->quad = "q3";

            root->q4 = new TreeNode();
            root->q4->data = q4_arr;
            root->q4->size = quadSize;
            root->q4->color = colorCheck(q4_arr, quadSize);
            root->q4->quad = "q4";

            buildTree(root->q1, q1_arr, quadSize);
            buildTree(root->q2, q2_arr, quadSize);
            buildTree(root->q3, q3_arr, quadSize);
            buildTree(root->q4, q4_arr, quadSize);
        }
    }


    void writeTree(TreeNode* root) {
        if (root == NULL) {
            return;
        }
        if (root->quad == "root") {
            ofstream myfile;
            myfile.open("root.txt");
            myfile << "";
            myfile.close();
            myfile.open("q1.txt");
            myfile << "";
            myfile.close();
            myfile.open("q2.txt");
            myfile << "";
            myfile.close();
            myfile.open("q3.txt");
            myfile << "";
            myfile.close();
            myfile.open("q4.txt");
            myfile << "";
            myfile.close();

        }
        ofstream myfile;
        myfile.open(root->quad + ".txt", ios::app);
        myfile << "Position: " << root->quad << " Color:" << root->color;
        myfile << " q1:" << root->q1;
        myfile << " q2:" << root->q2;
        myfile << " q3:" << root->q3;
        myfile << " q4:" << root->q4;




        myfile << endl;
        myfile.close();
        writeTree(root->q1);
        writeTree(root->q2);
        writeTree(root->q3);
        writeTree(root->q4);

    }

};
int main() {

    // Read the image file into a cv::Mat object
    Mat img = imread("C:\\Users\\Shekhani Laptops\\source\\repos\\opencvprojectA4\\opencvprojectA4\\t2.bmp");

    // Check if the image was successfully loaded
    if (img.empty()) {
        cerr << "loading image unsuccessful" << endl;
        return 1;
    }

    int size = img.rows;


    int** pixel_arr = new int* [size];
    for (int i = 0; i < size; i++) {
        pixel_arr[i] = new int[size];
    }

    for (int i = 0; i < size; i++) {
        for (int j = 0; j < size; j++) {
            pixel_arr[i][j] = static_cast<int>(img.at<uchar>(i, j));
        }

    }

    //write pixels to file
    ofstream myfile;
    myfile.open("pixels.txt");
    for (int i = 0; i < size; i++) {
        for (int j = 0; j < size; j++) {
            myfile << pixel_arr[i][j] << " , ";
        }
        myfile << "\n";
    }
    myfile.close();;

    LinkedList l;
    l.convertTo2dLL(pixel_arr, size, size);
    l.writeToFile();

    QuadTree qt;
    qt.buildTree(qt.root, pixel_arr, size);
    qt.writeTree(qt.root);


    return 0;
}

